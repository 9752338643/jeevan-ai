import streamlit as st
from datetime import date
from database import init_db, add_task, list_tasks, update_task_status, delete_task
from assistant import respond

st.set_page_config(page_title="Jeevan AI", page_icon="🤖", layout="centered")
init_db()

st.title("🤖 Jeevan AI")
st.caption("Your personal assistant • Phase 1 starter")

if "chat" not in st.session_state:
    st.session_state.chat = [
        {"role": "assistant", "content": "Hello! I'm Jeevan AI. I can help you organize tasks and plan your day. Try: “Plan my day” or “Add task: Prepare Physics notes.”"}
    ]

tab_chat, tab_tasks, tab_today = st.tabs(["💬 Assistant", "✅ Tasks", "📅 Today"])

with tab_chat:
    for message in st.session_state.chat:
        with st.chat_message(message["role"]):
            st.write(message["content"])

    prompt = st.chat_input("Message Jeevan AI...")
    if prompt:
        st.session_state.chat.append({"role": "user", "content": prompt})
        answer = respond(prompt)
        st.session_state.chat.append({"role": "assistant", "content": answer})
        st.rerun()

with tab_tasks:
    st.subheader("Add a task")
    with st.form("add_task_form", clear_on_submit=True):
        title = st.text_input("Task", placeholder="e.g. Prepare Class 12 Physics worksheet")
        due = st.date_input("Due date", value=date.today())
        priority = st.selectbox("Priority", ["Normal", "High", "Urgent"])
        submitted = st.form_submit_button("Add task", use_container_width=True)
        if submitted:
            if title.strip():
                add_task(title.strip(), str(due), priority)
                st.success("Task added.")
                st.rerun()
            else:
                st.warning("Please enter a task.")

    st.subheader("Your task list")
    tasks = list_tasks()
    if not tasks:
        st.info("No tasks yet. Add your first task above.")
    for task in tasks:
        task_id, task_title, due_date, priority, status = task
        with st.container(border=True):
            st.write(f"**{task_title}**")
            st.caption(f"Due: {due_date}  •  Priority: {priority}  •  Status: {status}")
            c1, c2 = st.columns(2)
            if status != "Done":
                if c1.button("Mark done", key=f"done_{task_id}", use_container_width=True):
                    update_task_status(task_id, "Done")
                    st.rerun()
            else:
                if c1.button("Reopen", key=f"open_{task_id}", use_container_width=True):
                    update_task_status(task_id, "Pending")
                    st.rerun()
            if c2.button("Delete", key=f"delete_{task_id}", use_container_width=True):
                delete_task(task_id)
                st.rerun()

with tab_today:
    st.subheader(f"Your plan for {date.today().strftime('%d %B %Y')}")
    today_tasks = [t for t in list_tasks() if t[2] == str(date.today()) and t[4] != "Done"]
    if today_tasks:
        for task in today_tasks:
            st.write(f"- **{task[1]}** ({task[3]})")
    else:
        st.info("No pending tasks due today.")
    st.write("**Suggested routine**")
    st.write("1. Choose your three most important tasks.")
    st.write("2. Work on one task at a time.")
    st.write("3. Review unfinished tasks before the day ends.")

st.divider()
st.caption("Jeevan AI v0.1 • Starter project. Do not enter passwords, banking details, or sensitive personal information.")
