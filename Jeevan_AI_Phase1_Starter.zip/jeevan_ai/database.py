import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "jeevan.db"

def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)

def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                due_date TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'Normal',
                status TEXT NOT NULL DEFAULT 'Pending'
            )
        """)
        conn.commit()

def add_task(title, due_date, priority="Normal"):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO tasks (title, due_date, priority) VALUES (?, ?, ?)",
            (title, due_date, priority)
        )
        conn.commit()

def list_tasks():
    with get_connection() as conn:
        return conn.execute(
            "SELECT id, title, due_date, priority, status FROM tasks ORDER BY due_date, id DESC"
        ).fetchall()

def update_task_status(task_id, status):
    with get_connection() as conn:
        conn.execute("UPDATE tasks SET status = ? WHERE id = ?", (status, task_id))
        conn.commit()

def delete_task(task_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        conn.commit()
