from datetime import date
from database import add_task, list_tasks

def respond(message: str) -> str:
    """Rule-based starter assistant. A real language model will be connected in Phase 2."""
    text = message.strip()
    lower = text.lower()

    if lower.startswith("add task:"):
        title = text.split(":", 1)[1].strip()
        if not title:
            return "Please write the task after 'Add task:'."
        add_task(title, str(date.today()), "Normal")
        return f"Added this task for today: **{title}**."

    if "plan my day" in lower or "today's plan" in lower or "todays plan" in lower:
        tasks = [t for t in list_tasks() if t[2] == str(date.today()) and t[4] != "Done"]
        if not tasks:
            return "You have no pending tasks due today. Add a task in the Tasks tab, then ask me to plan your day."
        lines = ["Here are your pending tasks for today:"]
        for i, task in enumerate(tasks, 1):
            lines.append(f"{i}. {task[1]} — {task[3]} priority")
        lines.append("Start with the urgent or high-priority task, then review your progress.")
        return "\n".join(lines)

    if "show my tasks" in lower or "list my tasks" in lower:
        tasks = list_tasks()
        if not tasks:
            return "You don't have any tasks yet."
        return "\n".join(
            f"- {t[1]} | due {t[2]} | {t[3]} priority | {t[4]}"
            for t in tasks
        )

    if any(word in lower for word in ["hello", "hi", "namaste", "hey"]):
        return "Hello! How can I help you today? You can ask me to plan your day, show your tasks, or add a task."

    return (
        "I'm currently running in starter mode, so I can manage basic tasks and daily plans. "
        "Try one of these commands:\n"
        "- `Add task: Prepare tomorrow's lesson`\n"
        "- `Plan my day`\n"
        "- `Show my tasks`\n\n"
        "In Phase 2, we'll connect a language model so I can understand more natural instructions."
    )
