# Jeevan AI — Phase 1

A beginner-friendly, mobile-friendly Python assistant starter built with Streamlit and SQLite.

## Features
- Mobile-friendly chat-style interface
- Add, list, complete, reopen, and delete tasks
- Basic rule-based assistant commands
- Daily task view
- Local SQLite database

## Run locally (computer)
1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create a virtual environment:
   `python -m venv .venv`
4. Activate it:
   - Windows: `.venv\Scripts\activate`
   - macOS/Linux: `source .venv/bin/activate`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Start:
   `streamlit run app.py`

## Use from an iPhone
Recommended path:
1. Create a GitHub account if you do not already have one.
2. Upload this project to a new GitHub repository.
3. Open Streamlit Community Cloud: https://share.streamlit.io/
4. Sign in with GitHub and authorize access to the repository.
5. Choose the repository, branch `main`, and main file `app.py`.
6. Deploy, then open the app URL in Safari and use Share → Add to Home Screen.

Deployment services and free-tier limits can change. A hosted app may sleep when unused.

## Important data warning
The included SQLite database is stored in the app's filesystem. On some hosted platforms, local files may be reset during redeploys or restarts. Do not use this starter for critical records. Before using it for real information, we will add a persistent database and backups.

## Commands
- `Add task: Prepare tomorrow's lesson`
- `Plan my day`
- `Show my tasks`

## Privacy
Do not enter passwords, banking information, identity numbers, or sensitive personal information.
